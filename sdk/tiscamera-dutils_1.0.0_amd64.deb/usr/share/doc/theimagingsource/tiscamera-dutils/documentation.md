# tcamdutils

tiscamera-dutils are a gstreamer-1.0 module that includes a multitude
of image enhancement/conversion algorithms. These include format conversions
like debayering, camera adjustments like auto-exposure and additional functionality
like tonemapping.

## Restrictions

This release (v1.0.0) currently supports x86_64 and requires SSE 4.1 as a minimum
supported instruction set, but can use up to AVX2 instructions.

### Unsupported devices

Not supported are the following devices:

- DFK AFU050-L34

Using them with tiscamera and tiscamera-dutils will likely prevent image retrieval.

## Requirements

The tiscamera project has to be installed.
If tiscamera has been compiled manually the flag BUILD_TOOLS has to be enabled.
tcamdutils will only work if a 'The Imaging Source' camera is present on the system.

## Available Conversions

Format your camera has                              Format that tcamdutils gives

video/x-raw, format=(string)GRAY16_LE           ==> video/x-raw, format=(string)GRAY16_LE
video/x-raw, format=(string)GRAY8               ==> video/x-raw, format=(string)GRAY8
video/x-bayer, format=(string)bggr              ==> video/x-raw, format=(string)BGRx
video/x-bayer, format=(string)bggr              ==> video/x-raw, format=(string)GRAY8
video/x-bayer, format=(string)gbrg              ==> video/x-raw, format=(string)BGRx
video/x-bayer, format=(string)gbrg              ==> video/x-raw, format=(string)GRAY8
video/x-bayer, format=(string)grbg              ==> video/x-raw, format=(string)BGRx
video/x-bayer, format=(string)grbg              ==> video/x-raw, format=(string)GRAY8
video/x-bayer, format=(string)rggb              ==> video/x-raw, format=(string)BGRx
video/x-bayer, format=(string)rggb              ==> video/x-raw, format=(string)GRAY8
video/x-bayer, format=(string)bggr16            ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)bggr16            ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)gbrg16            ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)gbrg16            ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)grbg16            ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)grbg16            ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)rggb16            ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)rggb16            ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)bggr12sp          ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)bggr12sp          ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)gbrg12sp          ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)gbrg12sp          ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)grbg12sp          ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)grbg12sp          ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)rggb12sp          ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)rggb12sp          ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)bggr12p           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)bggr12p           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)gbrg12p           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)gbrg12p           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)grbg12p           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)grbg12p           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)rggb12p           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)rggb12p           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)bggr12m           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)bggr12m           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)gbrg12m           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)gbrg12m           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)grbg12m           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)grbg12m           ==> video/x-raw, format=(string)RGBx64
video/x-bayer, format=(string)rggb12m           ==> video/x-raw, format=(string)GRAY16_LE
video/x-bayer, format=(string)rggb12m           ==> video/x-raw, format=(string)RGBx64
video/x-raw, format=(string)YUY2                ==> video/x-raw, format=(string)YUY2
video/x-raw, format=(string)IYU1                ==> video/x-raw, format=(string)IYU1


## Available Properties

The properties that tcamdutils will offer depend on the currently used conversion.
Changing the input/output formats will potentially change the available properties.
Many will only be available once the state is set to PLAYING.

If your camera has an internal implementation of a property, e.g. 'Exposure Auto',
then tcamdutils will not offer the property and disable the internal algorithms for said property.

Below is a table of all available properties:

| Name                          | Description                                                         |
|-------------------------------|---------------------------------------------------------------------|
| Exposure Auto                 | Automatic Adjustments of Exposure                                   |
|                               |                                                                     |
| Exposure Min                  | Minimum Value Exposure Auto may set                                 |
|                               |                                                                     |
| Exposure Max                  | Maximum Value Exposure Auto may set                                 |
|                               |                                                                     |
| Gain Auto                     | Automatic Adjustments of Gain                                       |
|                               |                                                                     |
| Iris Auto                     | Automatic Adjustments of Iris                                       |
|                               |                                                                     |
| Focus Auto                    | Adjust focus property until image is considered focused             |
|                               |                                                                     |
| Highlight Reduction           |                                                                     |
|                               |                                                                     |
| Exposure Auto Reference       | Average Brightness the image should have                            |
|                               |                                                                     |
| Whitebalance                  | Enable/Disable application of whitebalance values                   |
|                               |                                                                     |
| Whitebalance Auto             | Automatically and continually determine correct whitebalance values |
|                               |                                                                     |
| Whitebalance One Push         | Determine whitebalance values once                                  |
|                               |                                                                     |
| Whitebalance Red              | Whitebalance value for the red channel                              |
|                               |                                                                     |
| Whitebalance Green            | Whitebalance value for the green channel                            |
|                               |                                                                     |
| Whitebalance Blue             | Whitebalance value for the blue channel                             |
|                               |                                                                     |
| Brightness                    |                                                                     |
|                               |                                                                     |
| Noise Reduction               | Reduces noise in the image                                          |
|                               |                                                                     |
| Sharpness                     | Change edge contrast                                                |
|                               |                                                                     |
| Saturation                    | Change color intensity                                              |
|                               |                                                                     |
| Tonemapping                   | Enable HDR                                                          |
|                               |                                                                     |
| Tonemapping Global Brightness |                                                                     |
|                               |                                                                     |
| Tonemapping Intensity         |                                                                     |
|                               |                                                                     |
| Contrast                      |                                                                     |
|                               |                                                                     |
| Hue                           |                                                                     |


The following table shows when certain properties can be expected to exist.


| conversion                 | Whitebalance | Saturation/Hue | Brightness/Contrast | Sharpness/Denoise | Gamma | Tonemapping |
|----------------------------|--------------|----------------|---------------------|-------------------|-------|-------------|
|                            |              |                |                     |                   |       |             |
| GRAY16_LE ==> GRAY16_LE    |              |                | X                   | X                 | X     | X           |
| GRAY8 ==> GRAY8            |              |                | X                   | X                 | X     | X           |
| bayer 8-bit ==> BGRx       | X            | X              | X                   | X                 | X     | X           |
| bayer 8-bit ==> GRAY8      |              |                |                     |                   |       |             |
| bayer 16-bit ==> GRAY16_LE |              |                |                     |                   |       |             |
| bayer 16-bit ==> RGBx64    | X            | X              | X                   | X                 | X     | X           |
| bggr12sp ==> GRAY16_LE     |              |                |                     |                   |       |             |
| bggr12sp ==> RGBx64        | X            | X              | X                   | X                 | X     | X           |
| rggb12p ==> GRAY16_LE      |              |                |                     |                   |       |             |
| rggb12p ==> RGBx64         | X            | X              | X                   | X                 | X     | X           |
| rggb12m ==> GRAY16_LE      |              |                |                     |                   |       |             |
| rggb12m ==> RGBx64         | X            | X              | X                   | X                 | X     | X           |
| YUY2 ==> YUY2              |              | X              | X                   | X                 |       |             |
| IYU1 ==> IYU1              |              | X              | X                   | X                 |       |             |



## Usage

The tiscamera-dutils are a drop-in for our open source gstreamer elements that are optimized for performance.
They contain additional properties like tonemapping.

If you are using the tcambin for image retrieval you can continue doing so.
The tcambin detects the presence of the tcamdutils and uses them automatically.

To disable this behavior set the property `use-dutils` to `false`.

    .... ! tcambin use-dutils=false ! ....


The tcamdutils have an automatic load balancing that distributes the image analysis / correction on all available cores.

### Using 10/12/14/16 bit bayer formats

These formats have to be explicitly selected to be used.

#### Manual Pipeline

     tcamsrc ! video/x-bayer format=bggrXX ! tcamdutils ! tcambiteater ! ...

The only purpose of the tcambiteater element is to reduce BGRx64 to BGRx.
This is useful when wanting to display the resulting image.


#### Automatic Pipelines

If you want to use the tcambin you can set the property `device-caps`.
This influences the internal caps negotiation to only allow that format.

     tcambin device-caps="video/x-bayer,format=bggr12" ! video/x-raw,format=BGRx ! ....

The internal pipeline would look like:

     tcamsrc ! video/x-bayer format=bggr12 ! tcamdutils ! tcambiteater ! ...

The pipeline that is used can always be found in the gstreamer log output of tcambin.
See https://www.theimagingsource.com/documentation/tiscamera/logging.html#gstreamer
